import {readFile, writeFile, readdir, mkdir} from 'fs/promises';
import {join, extname, dirname} from 'path';
import {fileURLToPath} from 'url'; 

const __dirname = dirname(fileURLToPath(import.meta.url));


async function calculateSalesTotal(salesFiles){
  let salesTotal = 0;

  for(file of salesFiles){
    const data = JSON.parse(await readFile(file));

    salesTotal += data.total;
  }
  return salesTotal;
}


async function findSalesFiles(folderName) {
  let salesFiles = [];

  async function findFiles(folderName) {
    const items = await readdir(folderName, { withFileTypes: true });

    for (const item of items) {
      if (item.isDirectory()) {
        await findFiles(join(folderName, item.name));
      } else {
        if (extname(item.name) === ".json") {
          await salesFiles.push(join(folderName, item.name));
        }
      }
    }
  }

  await findFiles(folderName);

  return salesFiles;
}

async function main() {
  const salesDir = join(__dirname, "stores");
  const salesTotalsDir = join(__dirname, "salesTotals");

  try {
    await mkdir(salesTotalsDir);
  } catch {
    console.log(`${salesTotalsDir} already exists.`);
  }

  const salesFiles = await findSalesFiles(salesDir);

  const salesTotal = await calculateSalesTotal(salesFiles);

  await writeFile(
    join(salesTotalsDir, "totals.txt"),
    `Total at ${new Date().toLocaleDateString()} : ${salesTotal}€\r\n`,
    {flag: "a"}
  );
  console.log(`Wrote sales totals to ${salesTotalsDir}`);
}

main();