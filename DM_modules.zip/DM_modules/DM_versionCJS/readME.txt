- Main
    le code permet de récupérer l'ensemble des fichiers(chemins) d'un dossier qui concernent la vente, 
    puis de lire dans chacun eux et de récupérer des données afin de pouvoir calculer le total des ventes. 
    On écrit ce total dans un fichier totals.txt qu'on a ajouté dans la directory qu'on a créée dans le main. 
    On exécute la fonction findSalesFiles sur un dossier que l'on nomme dans le main "stores" et qui est présent dans la directory où 
    on exécute le code.
  
La fonction calculateSalesTotal(salesFiles) :
- Elle prend un ensemble=tableau de fichiers .json en paramètre et retoune le total des ventes stocké dans la variable "salesTotal".
- On a une boucle for qui parcourt un à un chacun de ces fichiers. 
- Dans la variable "data", on va stocker le contenu du ième fichier grâce à la méthode readFile, elle retoune d'abord le contenu du
fichier en String, puis on transforme cette chaine en un objet avec la méthode parse. 
Cela permet d'aller chercher l'attribut data.total de l'objet stocké dans "data". 
- Enfin, on ajoute ce total à la variable total des ventes global.


- la fonction findSalesFiles(fileName) permet de renvoyer un tableau de tous les fichiers/chemins étant dans fileName et qui correspondent aux ventes.
Cette même fonction comprend la fonction findFile. Cette fonction va d'abord stocker dans "items"
un tableau qui contient les noms de fichiers et de répertoires que l'on trouve dans "folderName".
Ensuite, dans la boucle, pour chacun des fichiers, on va vérifier 2 cas :

    - si item est une directory == un dossier, alors on va rappeler findFile (récursivité) sur ce sous-répertoire pour avoir le nom de ses fichers.


    - sinon, dans le cas où item est un fichier .json, on insére dans le tableau résultat le chemin vers ce fichier = nom du fichier. 
